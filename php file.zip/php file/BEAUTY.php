<!DOCTYPE>
<html>
 <head>
 <title>table project</title>
 </head>
   <body>
   
  <table border="0" width="100%">
  
       <tr>
           <th><img src="30-super-stay-24h-full-coverage-liquid-maybelline-new-york-original-imafajcajfrprkrw.jpeg" height="400px" width="200px">
		   <br><br>MAYBELLINE NEW YORK Super Stay 24H <br>Full coverage Liquid Foundation<br>(Classic Ivory 120, 30 ml)<br>₹750</th>
		   <th><img src="new-york-fit-me-concealer-maybelline-original-imaf6ec7cxd5swze.jpeg" height="300px" width="200px">
		   <br><br>MAYBELLINE NEW YORK Fit Me Concealer  <br>(10 Light, 6.8 ml)<br>₹475</th>
	
	       <th><br><br><img src="8-5-fit-me-matte-plus-poreless-powder-maybelline-original-imaf6ec7zvzq5ruz.jpeg" height="300px" width="200px">
		   <br><br><br><br>MAYBELLINE NEW YORK Fit Me <br>Matte Plus Poreless Powder Compact  <br>(Porcelain - 110, 8.5 g)<br>₹549</th>
      </tr>
  </table>
    <br>
  <table border="0" width="100%">
       <tr>
            <th><img src="7-5-fab-5-5-in-1-lipstick-7-5g-renee-original-imag6wtqfgmfq4tb.jpeg" height="300px" width="200px"><br>Renee Fab 5 (5 in 1 Lipstick), 7.5g <br>₹750</th>
	        <th><img src="12-candy-melts-vegan-lip-balm-berry-feast-tinted-fruit-lip-balm-original-imag5qrsge6fue3k.jpeg" height="300px" width="200px"><br>Plum Candy Melts Vegan Lip Balm | Berry Feast <br>  (Pack of: 1, 12 g)<br>₹265</th>
	        <th><img src="9-insta-eye-liner-lakme-original-imafxahkhvpce22u.jpeg" height="400px" width="200px">
			<br>Lakmé Insta Eye Liner <br>9 ml  (Black)<br>₹130</th>
       </tr>
  </table>
  <br>
  <table border="0" width="100%">
  
       <tr>
           <th><img src="lash-sensational-mascara-maybelline-new-york-original-imafydws79pk2f9j.jpeg" height="300px" width="200px">
		   <br>MAYBELLINE NEW YORK Lash Sensational <br>Mascara 10 ml  (Black)<br>₹399</th>
	       <th><img src="12-absolute-spotlight-eyeshadow-palette-lakme-original-imag689m33sf2yyh.jpeg" height="300px" width="200px">
		   <br>Lakmé Absolute Spotlight Eyeshadow Palette <br>12 g  (Smokin Glam)<br>₹805</th>
	       <th><img src="125-skin-naturals-micellar-cleansing-water-garnier-original-imafhgmfg7jfeu8z.jpeg" height="300px" width="200px">
		   <br>GARNIER Skin Naturals, Micellar Cleansing Water <br>Makeup Remover  (125 ml)<br>₹150</th>
       </tr>
  </table>
    </body>
 </html>	