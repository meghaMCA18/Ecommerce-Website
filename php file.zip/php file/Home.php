<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home Page</title>

	<link rel="stylesheet" type="text/css" href="Home.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

	<div class="table1">
		<table >	
			<tr>
				<td align="center" style="color:blue;">&emsp;&emsp;&emsp;&emsp;<b>Everything</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td>			
				<td>
					<div class="topnav" style="background-color:grey;" >
					
					    <a href="Login.php">Login</a>
						<a href="register.php">Sign Up</a>
  						<a href="pic.php">About Us</a>
					     
  						<!-- <a href="#Contact Us">Contact Us</a> -->
					</div>
				</td>
				<td>
				&emsp;&emsp;<a href="Shopping_cart/cart.php"><button style="font-size:24px"><i class="fa fa-shopping-cart"></i></button></a>
				</td>
			</tr>
		</table>
	</div>
    <br><br><br>


    <div class="dropdown">
        <div class="menu-bar">
        <ul>
            <li class="active"><a href="http://localhost/ecommerce/Home.php"><i class="fa fa-home"></i><br>Home</a>
            </li>
        <li><a href="fashion/fashion.php"><i class="fa fa-shopping-bag"></i><br>Fashion</a></li>
        <li><a href="electronics/electronic.php"><i class="fa fa-laptop"></i><i class="fa fa-headphones"></i><br>Electronics</a></li>
        <li ><a href="beauties/beauty.php"><i class="fa fa-envira"></i><br>Beauty</a></li>
        <li><a href="books/book.php"><i class="fa fa-book" ></i><br>Books</a></li>
        <li><a href="bags/bag.php"><i class="fa fa-book" ></i><br>Bags</a></li>
	</div>

    <div>
        <a href="#"><img src="image/banner1.jpg" width="100%"></a>
    </div>

    <br>
    <table border="0" width="100%" bgcolor="white">
        <tr>
            <td colspan="5"><h2>School Bags</h2><hr></td>
        </tr>
        <tr>
            <th><a href="bags/bag.php"><img src="image/bag1.jpeg" width="65%"></a></th>
            <th><a href="bags/bag.php"><img src="image/bag2.jpeg" width="65%"></a></th>
            <th><a href="bags/bag.php"><img src="image/bag3.jpeg" width="65%"></a></th>
            <th><a href="bags/bag.php"><img src="image/bag4.jpeg" width="65%"></a></th>
            <th><a href="bags/bag.php"><img src="image/bag5.jpeg" width="65%"></a></th>
        </tr>
        <tr>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
        </tr>    
        <tr>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 45%Off</th>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 55%Off</th>
            <th id="price">Upto 50%Off</th>
        </tr>    
    </table>

    <br>
    <table border="0" width="100%" bgcolor="white">
        <tr>
            <td colspan="5"><h2>Top Deals on Electronics</h2><hr></td>
        </tr>
        <tr>
            <th><a href="electronics/electronic.php"><img src="image/eletronics1.jpeg" width="65%"></a></th>
            <th><a href="electronics/electronic.php"><img src="image/eletronics2.jpeg" width="65%"></a></th>
            <th><a href="electronics/electronic.php"><img src="image/eletronics3.jpeg" width="65%"></a></th>
            <th><a href="electronics/electronic.php"><img src="image/eletronics4.jpeg" width="65%"></a></th>
            <th><a href="electronics/electronic.php"><img src="image/eletronics5.jpeg" width="65%"></a></th>
        </tr> 
        <tr>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
        </tr>      
        <tr>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 45%Off</th>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 55%Off</th>
            <th id="price">Upto 50%Off</th>
        </tr>    
    </table>

    <br>
    <table border="0" width="100%" bgcolor="white">
        <tr>
            <td colspan="5"><h2>Best Deals on Beauty Products</h2><hr></td>
        </tr>
        <tr>
            <th><a href="beauties/beauty.php"><img src="image/beauty1.jpeg" width="65%"></a></th>
            <th><a href="beauties/beauty.php"><img src="image/beauty2.jpeg" width="65%"></a></th>
            <th><a href="beauties/beauty.php"><img src="image/beauty3.jpeg" width="65%"></a></th>
            <th><a href="beauties/beauty.php"><img src="image/beauty4.jpeg" width="65%"></a></th>
            <th><a href="beauties/beauty.php"><img src="image/beauty5.jpeg" width="65%"></a></th>
        </tr>
        <tr>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
        </tr>       
        <tr>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 45%Off</th>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 55%Off</th>
            <th id="price">Upto 50%Off</th>
        </tr>    
    </table>
			
    <br>
    <table border="0" width="100%" bgcolor="white">
        <tr>
            <td colspan="5"><h2>Top Fashion Styles</h2><hr></td>
        </tr>
        <tr>
            <th><a href="fashion/fashion.php"><img src="image/fashion1.jpeg" width="65%"></a></th>
            <th><a href="fashion/fashion.php"><img src="image/fashion2.jpeg" width="65%"></a></th>
            <th><a href="fashion/fashion.php"><img src="image/fashion3.jpeg" width="65%"></a></th>
            <th><a href="fashion/fashion.php"><img src="image/fashion4.jpeg" width="65%"></a></th>
            <th><a href="fashion/fashion.php"><img src="image/fashion5.jpeg" width="65%"></a></th>
        </tr> 
        <tr>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
        </tr>      
        <tr>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 45%Off</th>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 55%Off</th>
            <th id="price">Upto 50%Off</th>
        </tr>    
    </table>

    <br>
    <table border="0" width="100%" bgcolor="white">
        <tr>
            <td colspan="5"><h2>Books</h2><hr></td>
        </tr>
        <tr>
            <th><a href="books/book.php"><img src="image/book1.jpeg" width="65%"></a></th>
            <th><a href="books/book.php"><img src="image/book2.jpeg" width="65%"></a></th>
            <th><a href="books/book.php"><img src="image/book3.jpeg" width="65%"></a></th>
            <th><a href="books/book.php"><img src="image/book4.jpeg" width="65%"></a></th>
            <th><a href="books/book.php"><img src="image/book5.jpeg" width="65%"></a></th>
        </tr>
        <tr>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
            <th>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star" style="color: orange;"></span>
                <span class="fa fa-star"></span>
            </th>
        </tr>       
        <tr>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 45%Off</th>
            <th id="price">Upto 50%Off</th>
            <th id="price">Upto 55%Off</th>
            <th id="price">Upto 50%Off</th>
        </tr>    
    </table>
    <table width="100%" height="60" bgcolor="#000000" border="0" cellpadding="5" cellspacing="5">
		<tr>
			<td align="center">
				<font face="Verdana , Geneva , sans=serif" color="white">
				Home - About - Services - Clints - Contact <br> <br> &copy; 2021 by Everything Shopping Website </font>
			</td>
		</tr>
	</table>
    

</body>
</html>


