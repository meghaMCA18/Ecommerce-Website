<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/5cd4730d1a.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
    <title>PROJECT</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap');
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }
        html{
            scroll-behavior: smooth;
            font-size: 62.5%;
        }
        body{
            animation: transitionIn 2s;
            font-family: 'Montserrat', sans-serif;
            margin-top: 30px;
        }
        /* ############################## UTILITY CLASSESS */
        .container{
            margin: 0 auto;
            max-width: 1200px;
            width: 90%;
        }
        /* ######################### SINGLE PRODUCT  */
        .product{
            width: 250px;
            height: auto;
            padding: 10px 10px;
            margin: 20px 20px;
            background-color: rgb(221, 220, 187);
            overflow: hidden;
            object-fit: cover;
            transition: all 0.5s;
        }
        .product:hover{
            transform: scale(1.04);
        }
        .product img{
            width: 100%;
        }
        .product p{
            padding: 10px 0;
            font-size: 15px;
            font-weight: 500;
        }
        .product .fas,.product .far{
            font-size: 15px;
            color: orangered;
        }
        .products{
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
        }
        @media only screen and (max-width: 650px) {
            .product{
                width: 100%;
            }
        }
		.dropdown{
    background-color: floralwhite
    background-size: cover;
    background-position: center;    
    font-family: sans-serif;
}
.menu-bar{
    background: rgb(0,0,205);
    text-align: center;
}
.menu-bar ul{
    display:inline-flex;
    list-style:none;
    color: #fff;
}
.menu-bar ul li{
    width: 110px;
    margin: 5px;
    padding: 10px;
}
.menu-bar ul li a{
    text-decoration: none;
    color: #fff;
}
.active, .menu-bar ul li:hover
{
    background: #2bab0d;
    border-radius: 3px;
}
.sub-menu-1{
    display:none;
}
.menu-bar ul li:hover .sub-menu-1
{
    display:block;
    position: absolute;
    background:rgb(0,100,0);
    margin-top: 15px;
    margin-left: -15px;
}
.menu-bar ul li:hover .sub-menu-1 ul
{
    display: block;
    margin: 10px;
}
.menu-bar ul li:hover .sub-menu-1 ul li{
    width:150px;
    padding: 10px;
    border-bottom: 1px dotted #fff;
    background: transparent;
    border-radius: 0;
    text-align:left;
}
.menu-bar ul li:hover .sub-menu-1 ul li:last-child
{
    border-bottom: none;
}
.menu-bar ul li:hover .sub-menu-1 ul li a:hover{
    color:#b2ff00;
}
    </style>
    
</head>


<body>
<div class="dropdown">
        <div class="menu-bar">
        <ul>
            <li class="active"><a href="http://localhost/ecommerce/Home.php"><i class="fa fa-home"></i><br>Home</a>
            </li>
        <li><a href="http://localhost/ecommerce/fashion/fashion.php"><i class="fa fa-shopping-bag"></i><br>Fashion</a></li>
        <li><a href="http://localhost/ecommerce/electronics/electronic.php"><i class="fa fa-laptop"></i><i class="fa fa-headphones"></i><br>Electronics</a></li>
        <li ><a href="http://localhost/ecommerce/beauties/beauty.php"><i class="fa fa-envira"></i><br>Beauty</a></li>
        <li><a href="http://localhost/ecommerce/books/book.php"><i class="fa fa-book" ></i><br>Books</a></li>
        <li><a href="http://localhost/ecommerce/bags/bag.php"><i class="fa fa-book" ></i><br>Bags</a></li>
	</div>
    <div class="container">
        <div class="products">
            <div class="product">
                <img src="./1.jpg" alt="">
                <p>Adidas Cotton T-Shirt</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 699.00 INR</p>
            </div>

            <div class="product">
                <img src="./6.jpg" alt="">
                <p>Puma Deep Black</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 1399.00 INR</p>
            </div>

            <div class="product">
                <img src="./7.jpg" alt="">
                <p>Puma Pant</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 1799.00 INR</p>
            </div>

            <div class="product">
                <img src="./3.jpg" alt="">
                <p>Banarasi Saree</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 5999.00 INR</p>
            </div>

            <div class="product">
                <img src="./8.jpg" alt="">
                <p>Modern Shirt & Pant</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 1599.00 INR</p>
            </div>

            <div class="product">
                <img src="./9.jpg" alt="">
                <p>Deep Black Kurta</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <p>Rs: 1499.00 INR</p>
            </div>

            <div class="product">
                <img src="./2.jpg" alt="">
                <p>Twin Full Combo For Kids</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 1000.00 INR</p>
            </div>

            <div class="product">
                <img src="./4.jpg" alt="">
                <p>Modern T-Shirt For Kids</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 1199.00 INR</p>
            </div>

            <div class="product">
                <img src="./5.jpg" alt="">
                <p>Stylish T-Shirt For Kid</p>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="far fa-star"></i>
                </div>
                <p>Rs: 799.00 INR</p>
            </div>


        </div>
    </div>
</body>
</html>